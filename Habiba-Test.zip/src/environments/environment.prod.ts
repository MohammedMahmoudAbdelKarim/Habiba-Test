export const environment = {
  production: true,
  // baseUrl: 'http://jewelry.ixscope.com/backend/api/'
  // baseUrl: 'http://127.0.0.1:8000/api/'
  baseUrl: 'http://jewelry.inspia.net/backend/api/'
  // baseUrl: 'http://testjewelry.inspia.net/backend/api/'
  // baseUrl: 'http://192.168.1.110/jewelry/public/api/'
  // baseUrl: 'localhost:8000/api/'
};
